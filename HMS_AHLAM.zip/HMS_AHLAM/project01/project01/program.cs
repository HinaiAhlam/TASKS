﻿using project01.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project01
{
    public class program

    {
        //1
        public static void RegisterPatient(HospitalContext context)
        {
            Console.WriteLine("Enter Patient Name:");
            string patientName = Console.ReadLine();

            Console.WriteLine("Enter Patient Age:");
            int patientAge = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Patient Gender:");
            string patientGender = Console.ReadLine();

            Console.WriteLine("Enter Patient Phone");
            string patientPhone = Console.ReadLine();

            Console.WriteLine("Enter Patient Email");
            string patientEmail = Console.ReadLine();


            Console.WriteLine("Enter Patient Blood Type");
            string patientBloodType = Console.ReadLine();

            int PatientId = (context.Patients.Count) + 1; //calculated

            //////////////////////////////////////////////
            //add Patient

            context.Patients.Add(
                 new Patient
                 {
                     PatientName = patientName,
                     PatientAge = patientAge,
                     PatientGender = patientGender,
                     PatientPhone = patientPhone,
                     PatientEmail = patientEmail,
                     PatientBloodType = patientEmail,
                     PatientId = PatientId
                 }

                );

            Console.WriteLine("Patient Added Successfully with ID " + PatientId);
        }

    

    
        
          
    
        //2
         public static void AddDoctor(HospitalContext context) 
        
        {
            Console.WriteLine("Enter Doctor Name:");
            string doctorName = Console.ReadLine();

            Console.WriteLine("Enter Doctor phon number:");
            string doctorPhone = Console.ReadLine();

            Console.WriteLine("Enter Doctor Specialization:");
            string doctorSpecialization = Console.ReadLine();

            Console.WriteLine("Enter Doctor Email");
            string doctorEmail = Console.ReadLine();

            Console.WriteLine("Enter Doctor ConsultationFee");
            decimal consultationFee = decimal.Parse(Console.ReadLine());


            

            int doctorId = (context.Doctors.Count) + 1; 


            context.Doctors.Add(
                 new Doctor
                 {
                     doctorName = doctorName,
                     doctorPhone = doctorPhone,
                     doctorSpecialization = doctorSpecialization,
                     doctorEmail = doctorEmail,
                     consultationFee = consultationFee,
                    doctorId = doctorId
                 }

                );

            Console.WriteLine("doctor Added Successfully with ID " + doctorId);
        }
        
        
        
        
        

        //3
        public static void ViewPatients( HospitalContext context) 
        
        {
            if (context.Doctors.Count == 0)
            {
                Console.WriteLine(" no patients in the list");
                return;
            }
            Console.WriteLine(" *********   patient list   **********");

            foreach (Patient patient in context.Patients)
            {
                Console.WriteLine("ID: " + patient.PatientId);
                Console.WriteLine("Name: " + patient.PatientName);
                Console.WriteLine("Age: " + patient.PatientAge);
                Console.WriteLine("Gender: " + patient.PatientGender);
                Console.WriteLine("Phone: " + patient.PatientPhone);

                Console.WriteLine("----------------");
            }
        }

        //4
        public static void ViewDoctorsBySpecialization( HospitalContext context) 
        {
            Console.WriteLine(" =====  Enter Specialization  =====");
            string Specialization= Console.ReadLine();
            bool found= false;
            foreach
                (Doctor doctor in context.Doctors)
            {

                if (doctor.doctorSpecialization == Specialization)
                {
                    found = true;
                    Console.WriteLine(doctor.doctorName);
                    Console.WriteLine(doctor.doctorPhone);

                }
            }
            if (found == false)
            {
                Console.WriteLine("No Doctors Found");
            }

        }
        //5
        public static void AddAvailableSlot( HospitalContext context) 
        {
        
           Console.WriteLine(" Enter Dector ID :");
            int doctorId = int.Parse(Console.ReadLine());

            Doctor doctor = null;
            foreach (Doctor d in context.Doctors)
            {
                if (d.doctorId == doctorId) 
                { 
                    doctor = d;
                    break;
                }

            }
            if (doctor == null) 
            {
                Console.WriteLine(" Doctor Is Not Found ! ");
                return;
            }
            Console.WriteLine(" Enter Avalible Date .");
            string SlotDate = Console.ReadLine();

            Console.WriteLine(" Enter Avalible Time .");
            string SlotTime = Console.ReadLine();

            AvailableSlot availableSlot = new AvailableSlot();

            availableSlot.SlotDate = SlotDate;
            availableSlot.SlotTime = SlotTime;
            availableSlot.IsBooked= false;

            doctor.AvailableSlots.Add(availableSlot);
            Console.WriteLine(" Sloot Add Succufully");

         }

        //6
        public static void BookAppointment( HospitalContext context) 
        {

            Console.WriteLine(" Enter Patient ID : ");
            int PatientId = int.Parse(Console.ReadLine());

            Patient patient = null;
            foreach (Patient pat in context.Patients)
            {
                if (pat.PatientId == PatientId)
                { 
                    patient = pat;
                    break;
                }
            }



            Console.WriteLine(" Enter Doctor ID : ");
            int doctorId = int.Parse(Console.ReadLine());

            Doctor doctor = null;
            foreach (Doctor doc in context.Doctors)
            {
                if (doc.doctorId == doctorId)
                {
                    doctor = doc;
                    break;
                }
            }

            if (doctor == null) 
            {
                Console.WriteLine(" Doctor Is Not Found !");
                return;
            }


            Console.WriteLine(" Available Slots:  ");
            foreach (AvailableSlot slot in doctor.AvailableSlots)
            {
                if (slot.IsBooked == false )
                {
                    Console.WriteLine(" slot.Time");              
                }
            }


            Console.WriteLine(" Enter Slot ID : ");
            int dSlotId = int.Parse(Console.ReadLine());
            AvailableSlot selectedslot =null;

            foreach(AvailableSlot slot in doctor.AvailableSlots) 
            {
                if (slot.IsBooked == false)
                {
                    selectedslot = slot;
                    break;
                }
            
            }
            if (selectedslot.IsBooked == true) 
            
            {
               Console.WriteLine("  Slot Not Avalible ! ");
                return;
            
            }




            Appointment appointment = new Appointment();
            appointment.PatientId = patient.PatientId;
            appointment.DoctorId = doctor.doctorId;
            appointment.SlotId = selectedslot.SlotId;
            appointment.AppointmentDate= selectedslot.SlotDate;
            appointment.AppointmentTime = selectedslot.SlotTime;
            appointment.Status = " Booked";
            context.Appointments.Add(appointment);


            selectedslot.IsBooked = true;
            Console.WriteLine(" Appointment booked successfully .");

        }





        //7
        public static void CancelAppointment( HospitalContext context) 
        
        { 
            Console.WriteLine(" Enter Appointment ID :  ");
            int AppointmentId = int.Parse(Console.ReadLine());



            Appointment appointment = null;

            foreach (Appointment app in context.Appointments)
            {
                if (app.AppointmentId == AppointmentId)
                {
                    appointment = app;
                    return;
                }
            }

            if (appointment == null)
            {
                Console.WriteLine("Appointment not found"); 
                return;    
            }

            if (appointment.Status== "Cancelled") 
            {
                Console.WriteLine("Appointment already cancelled");
                return;
            
            }

            appointment.Status = "Cancelled";


            foreach (Doctor doctor in context.Doctors)
            {

                if (doctor.doctorId == appointment.DoctorId)

                {
                    foreach (AvailableSlot slot in doctor.AvailableSlots)
                    {
                        if (slot.SlotId == appointment.SlotId)
                        {
                            slot.IsBooked = false;
                            break;
                        }

                    }

                }

            }
            Console.WriteLine("Appointment cancelled successfully");
        }


        //8
        public static void CreateMedicalRecord(HospitalContext context) 
        
        
        {
        Console.WriteLine(" Inter Enter Appointment ID: ");
            int AppointmentId = int.Parse(Console.ReadLine());

            Appointment appointment = null;


            foreach (Appointment appo in context.Appointments)
            {
                if (appo.AppointmentId== AppointmentId)
                {
                    appointment = appo;
                    return;
                }

            }

            if (appointment == null)
            {
                Console.WriteLine("Appointment not found");
                return;
            }

           Console.WriteLine("  Enter diagnosis");
            string diagnosis = Console.ReadLine();


            Console.WriteLine("  Enter Prescription");
            string Prescription = Console.ReadLine();



            Doctor doctor = null;


            foreach (Doctor d in context.Doctors) 
            {
                if (d.doctorId == appointment.DoctorId)
                { 
                doctor= d;
                    break;
                
                }
            }


            if (doctor == null)
            {
                Console.WriteLine("Doctor not found");
                return;
            }


            MedicalRecord record = new MedicalRecord();
            record.PatientId = appointment.PatientId;
            record.DoctorId = appointment.DoctorId;
            record.AppointmentId = appointment.AppointmentId;
            record.Diagnosis = diagnosis;
            record.Prescription = Prescription;
            record.VisitDate = appointment.AppointmentDate;
            record.VisitFee = doctor.consultationFee;



            context.MedicalRecords.Add(record);

            appointment.Status = "Completed";


            Console.WriteLine("Medical record created successfully");


        }



        //9
        public static void PatientMedicalHistory( HospitalContext context) 
        
        
        { 
        
        
        
        
        
        }
        //10
        public static void DoctorRevenueSummary(HospitalContext context) { }

    }
}